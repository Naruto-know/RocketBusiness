package com.fmbank.wangdai.cqpoquery.dao;

import com.fmbank.wangdai.cqpoquery.domain.ReportCollectionOverdueEnclosureInfo;

public interface ReportCollectionOverdueEnclosureInfoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ReportCollectionOverdueEnclosureInfo record);

    int insertSelective(ReportCollectionOverdueEnclosureInfo record);

    ReportCollectionOverdueEnclosureInfo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ReportCollectionOverdueEnclosureInfo record);

    int updateByPrimaryKey(ReportCollectionOverdueEnclosureInfo record);
}