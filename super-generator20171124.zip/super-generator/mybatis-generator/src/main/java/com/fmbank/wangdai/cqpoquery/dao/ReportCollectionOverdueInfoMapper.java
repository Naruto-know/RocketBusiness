package com.fmbank.wangdai.cqpoquery.dao;

import com.fmbank.wangdai.cqpoquery.domain.ReportCollectionOverdueInfo;

public interface ReportCollectionOverdueInfoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ReportCollectionOverdueInfo record);

    int insertSelective(ReportCollectionOverdueInfo record);

    ReportCollectionOverdueInfo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ReportCollectionOverdueInfo record);

    int updateByPrimaryKey(ReportCollectionOverdueInfo record);
}