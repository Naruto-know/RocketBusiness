package com.fmbank.wangdai.cqpoquery.dao;

import com.fmbank.wangdai.cqpoquery.domain.ReportCollectionOverdueContactsInfo;

public interface ReportCollectionOverdueContactsInfoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ReportCollectionOverdueContactsInfo record);

    int insertSelective(ReportCollectionOverdueContactsInfo record);

    ReportCollectionOverdueContactsInfo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ReportCollectionOverdueContactsInfo record);

    int updateByPrimaryKey(ReportCollectionOverdueContactsInfo record);
}