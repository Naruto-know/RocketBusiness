package com.fmbank.wangdai.cqpoquery.domain;

import java.math.BigDecimal;
import java.util.Date;

public class ReportCollectionOverdueInfo {
    /**
     * <pre>
     * 自增主键
     * 表字段： report_collection_overdue_info.ID
     * </pre>
     * 
     */
    private Integer id;

    /**
     * <pre>
     * 创建时间
     * 表字段： report_collection_overdue_info.SYSTIME
     * </pre>
     * 
     */
    private Date systime;

    /**
     * <pre>
     * 分区
     * 表字段： report_collection_overdue_info.STAT_DT
     * </pre>
     * 
     */
    private String statDt;

    /**
     * <pre>
     * 产品大类
     * 表字段： report_collection_overdue_info.PRODUCT_TYPE_ONE
     * </pre>
     * 
     */
    private String productTypeOne;

    /**
     * <pre>
     * 产品小类
     * 表字段： report_collection_overdue_info.PRODUCT_TYPE_THREE
     * </pre>
     * 
     */
    private String productTypeThree;

    /**
     * <pre>
     * 借款开始日期
     * 表字段： report_collection_overdue_info.LOAN_START_DATE
     * </pre>
     * 
     */
    private Date loanStartDate;

    /**
     * <pre>
     * 贷款金额
     * 表字段： report_collection_overdue_info.LOAN_AMOUNT
     * </pre>
     * 
     */
    private BigDecimal loanAmount;

    /**
     * <pre>
     * 借款申请编号
     * 表字段： report_collection_overdue_info.LOAN_APPLY_NO
     * </pre>
     * 
     */
    private String loanApplyNo;

    /**
     * <pre>
     * 逾期总金额
     * 表字段： report_collection_overdue_info.OVERDUE_AMOUNT
     * </pre>
     * 
     */
    private BigDecimal overdueAmount;

    /**
     * <pre>
     * 逾期本金
     * 表字段： report_collection_overdue_info.OVERDUE_PRINCIPAL
     * </pre>
     * 
     */
    private BigDecimal overduePrincipal;

    /**
     * <pre>
     * 剩余本金
     * 表字段： report_collection_overdue_info.SURPLUS_PRINCIPAL
     * </pre>
     * 
     */
    private BigDecimal surplusPrincipal;

    /**
     * <pre>
     * 剩余利息
     * 表字段： report_collection_overdue_info.SURPLUS_INTEREST
     * </pre>
     * 
     */
    private BigDecimal surplusInterest;

    /**
     * <pre>
     * 逾期利息
     * 表字段： report_collection_overdue_info.OVERDUE_INTEREST
     * </pre>
     * 
     */
    private BigDecimal overdueInterest;

    /**
     * <pre>
     * 逾期罚息
     * 表字段： report_collection_overdue_info.OVERDUE_PENALTY
     * </pre>
     * 
     */
    private BigDecimal overduePenalty;

    /**
     * <pre>
     * 逾期滞纳金
     * 表字段： report_collection_overdue_info.OVERDUE_LATEFEE
     * </pre>
     * 
     */
    private BigDecimal overdueLatefee;

    /**
     * <pre>
     * 还款期数
     * 表字段： report_collection_overdue_info.REPAYMENT_PERIODS
     * </pre>
     * 
     */
    private Long repaymentPeriods;

    /**
     * <pre>
     * 每期还款日
     * 表字段： report_collection_overdue_info.EACH_REPAYMENTDAY
     * </pre>
     * 
     */
    private Date eachRepaymentday;

    /**
     * <pre>
     * 每期还款金额
     * 表字段： report_collection_overdue_info.EACH_REPAYMENTAMOUNT
     * </pre>
     * 
     */
    private BigDecimal eachRepaymentamount;

    /**
     * <pre>
     * 其他费用
     * 表字段： report_collection_overdue_info.OTHER_AMOUNT
     * </pre>
     * 
     */
    private BigDecimal otherAmount;

    /**
     * <pre>
     * 逾期日期
     * 表字段： report_collection_overdue_info.OVERDUE_DATE
     * </pre>
     * 
     */
    private Date overdueDate;

    /**
     * <pre>
     * 逾期期数
     * 表字段： report_collection_overdue_info.OVERDUE_PERIODS
     * </pre>
     * 
     */
    private Long overduePeriods;

    /**
     * <pre>
     * 逾期天数
     * 表字段： report_collection_overdue_info.OVERDUE_DAY
     * </pre>
     * 
     */
    private Long overdueDay;

    /**
     * <pre>
     * 已还款金额
     * 表字段： report_collection_overdue_info.REPAYMENT_AMOUNT
     * </pre>
     * 
     */
    private BigDecimal repaymentAmount;

    /**
     * <pre>
     * 已还款期数
     * 表字段： report_collection_overdue_info.ALREADY_REPAYPERIODS
     * </pre>
     * 
     */
    private Long alreadyRepayperiods;

    /**
     * <pre>
     * 最近还款日期
     * 表字段： report_collection_overdue_info.LATELY_REPAYMENTDAY
     * </pre>
     * 
     */
    private Date latelyRepaymentday;

    /**
     * <pre>
     * 最近还款金额
     * 表字段： report_collection_overdue_info.LATELY_REPAYMENTAMOUNT
     * </pre>
     * 
     */
    private BigDecimal latelyRepaymentamount;

    /**
     * <pre>
     * 逾期管理费
     * 表字段： report_collection_overdue_info.OVERDUE_MANAGEFEE
     * </pre>
     * 
     */
    private BigDecimal overdueManagefee;

    /**
     * <pre>
     * 佣金比例
     * 表字段： report_collection_overdue_info.COMMISSION_RATE
     * </pre>
     * 
     */
    private BigDecimal commissionRate;

    /**
     * <pre>
     * 客户还款卡银行
     * 表字段： report_collection_overdue_info.CUSTOMER_REPAYMENT_BANK
     * </pre>
     * 
     */
    private String customerRepaymentBank;

    /**
     * <pre>
     * 客户还款卡号
     * 表字段： report_collection_overdue_info.CUSTOMER_REPAYMENT_CARDNO
     * </pre>
     * 
     */
    private String customerRepaymentCardno;

    /**
     * <pre>
     * 客户姓名
     * 表字段： report_collection_overdue_info.·CUSTOMER_NAME·
     * </pre>
     * 
     */
    private String ·customerName·;

    /**
     * <pre>
     * 身份证号码
     * 表字段： report_collection_overdue_info.IDENTITY_NO
     * </pre>
     * 
     */
    private String identityNo;

    /**
     * <pre>
     * 手机号码
     * 表字段： report_collection_overdue_info.MOBILE_NO
     * </pre>
     * 
     */
    private String mobileNo;

    /**
     * <pre>
     * 婚姻状态
     * 表字段： report_collection_overdue_info.MARRIAGE_STATUS
     * </pre>
     * 
     */
    private String marriageStatus;

    /**
     * <pre>
     * 省
     * 表字段： report_collection_overdue_info.PROVINCE
     * </pre>
     * 
     */
    private String province;

    /**
     * <pre>
     * 市
     * 表字段： report_collection_overdue_info.CITY
     * </pre>
     * 
     */
    private String city;

    /**
     * <pre>
     * 家庭住址
     * 表字段： report_collection_overdue_info.HOMEADDRESS
     * </pre>
     * 
     */
    private String homeaddress;

    /**
     * <pre>
     * 家庭电话
     * 表字段： report_collection_overdue_info.HOMEPHONE
     * </pre>
     * 
     */
    private String homephone;

    /**
     * <pre>
     * 身份证户籍地址
     * 表字段： report_collection_overdue_info.IDENTITY_REGISTER_ADDRESS
     * </pre>
     * 
     */
    private String identityRegisterAddress;

    /**
     * <pre>
     * 工作单位名称
     * 表字段： report_collection_overdue_info.WORK_COMPANY_NAME
     * </pre>
     * 
     */
    private String workCompanyName;

    /**
     * <pre>
     * 工作单位地址
     * 表字段： report_collection_overdue_info.WORK_COMPANY_ADDRESS
     * </pre>
     * 
     */
    private String workCompanyAddress;

    /**
     * <pre>
     * 工作单位电话
     * 表字段： report_collection_overdue_info.WORK_COMPANY_PHONE
     * </pre>
     * 
     */
    private String workCompanyPhone;

    /**
     * <pre>
     * 备注
     * 表字段： report_collection_overdue_info.REMARKS
     * </pre>
     * 
     */
    private String remarks;

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.ID
     *
     * @return the value of report_collection_overdue_info.ID
     *
     * @mbggenerated
     */
    public Integer getId() {
        return id;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.ID
     *
     * @param id the value for report_collection_overdue_info.ID
     *
     * @mbggenerated
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.SYSTIME
     *
     * @return the value of report_collection_overdue_info.SYSTIME
     *
     * @mbggenerated
     */
    public Date getSystime() {
        return systime;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.SYSTIME
     *
     * @param systime the value for report_collection_overdue_info.SYSTIME
     *
     * @mbggenerated
     */
    public void setSystime(Date systime) {
        this.systime = systime;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.STAT_DT
     *
     * @return the value of report_collection_overdue_info.STAT_DT
     *
     * @mbggenerated
     */
    public String getStatDt() {
        return statDt;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.STAT_DT
     *
     * @param statDt the value for report_collection_overdue_info.STAT_DT
     *
     * @mbggenerated
     */
    public void setStatDt(String statDt) {
        this.statDt = statDt == null ? null : statDt.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.PRODUCT_TYPE_ONE
     *
     * @return the value of report_collection_overdue_info.PRODUCT_TYPE_ONE
     *
     * @mbggenerated
     */
    public String getProductTypeOne() {
        return productTypeOne;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.PRODUCT_TYPE_ONE
     *
     * @param productTypeOne the value for report_collection_overdue_info.PRODUCT_TYPE_ONE
     *
     * @mbggenerated
     */
    public void setProductTypeOne(String productTypeOne) {
        this.productTypeOne = productTypeOne == null ? null : productTypeOne.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.PRODUCT_TYPE_THREE
     *
     * @return the value of report_collection_overdue_info.PRODUCT_TYPE_THREE
     *
     * @mbggenerated
     */
    public String getProductTypeThree() {
        return productTypeThree;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.PRODUCT_TYPE_THREE
     *
     * @param productTypeThree the value for report_collection_overdue_info.PRODUCT_TYPE_THREE
     *
     * @mbggenerated
     */
    public void setProductTypeThree(String productTypeThree) {
        this.productTypeThree = productTypeThree == null ? null : productTypeThree.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.LOAN_START_DATE
     *
     * @return the value of report_collection_overdue_info.LOAN_START_DATE
     *
     * @mbggenerated
     */
    public Date getLoanStartDate() {
        return loanStartDate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.LOAN_START_DATE
     *
     * @param loanStartDate the value for report_collection_overdue_info.LOAN_START_DATE
     *
     * @mbggenerated
     */
    public void setLoanStartDate(Date loanStartDate) {
        this.loanStartDate = loanStartDate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.LOAN_AMOUNT
     *
     * @return the value of report_collection_overdue_info.LOAN_AMOUNT
     *
     * @mbggenerated
     */
    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.LOAN_AMOUNT
     *
     * @param loanAmount the value for report_collection_overdue_info.LOAN_AMOUNT
     *
     * @mbggenerated
     */
    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.LOAN_APPLY_NO
     *
     * @return the value of report_collection_overdue_info.LOAN_APPLY_NO
     *
     * @mbggenerated
     */
    public String getLoanApplyNo() {
        return loanApplyNo;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.LOAN_APPLY_NO
     *
     * @param loanApplyNo the value for report_collection_overdue_info.LOAN_APPLY_NO
     *
     * @mbggenerated
     */
    public void setLoanApplyNo(String loanApplyNo) {
        this.loanApplyNo = loanApplyNo == null ? null : loanApplyNo.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OVERDUE_AMOUNT
     *
     * @return the value of report_collection_overdue_info.OVERDUE_AMOUNT
     *
     * @mbggenerated
     */
    public BigDecimal getOverdueAmount() {
        return overdueAmount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OVERDUE_AMOUNT
     *
     * @param overdueAmount the value for report_collection_overdue_info.OVERDUE_AMOUNT
     *
     * @mbggenerated
     */
    public void setOverdueAmount(BigDecimal overdueAmount) {
        this.overdueAmount = overdueAmount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OVERDUE_PRINCIPAL
     *
     * @return the value of report_collection_overdue_info.OVERDUE_PRINCIPAL
     *
     * @mbggenerated
     */
    public BigDecimal getOverduePrincipal() {
        return overduePrincipal;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OVERDUE_PRINCIPAL
     *
     * @param overduePrincipal the value for report_collection_overdue_info.OVERDUE_PRINCIPAL
     *
     * @mbggenerated
     */
    public void setOverduePrincipal(BigDecimal overduePrincipal) {
        this.overduePrincipal = overduePrincipal;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.SURPLUS_PRINCIPAL
     *
     * @return the value of report_collection_overdue_info.SURPLUS_PRINCIPAL
     *
     * @mbggenerated
     */
    public BigDecimal getSurplusPrincipal() {
        return surplusPrincipal;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.SURPLUS_PRINCIPAL
     *
     * @param surplusPrincipal the value for report_collection_overdue_info.SURPLUS_PRINCIPAL
     *
     * @mbggenerated
     */
    public void setSurplusPrincipal(BigDecimal surplusPrincipal) {
        this.surplusPrincipal = surplusPrincipal;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.SURPLUS_INTEREST
     *
     * @return the value of report_collection_overdue_info.SURPLUS_INTEREST
     *
     * @mbggenerated
     */
    public BigDecimal getSurplusInterest() {
        return surplusInterest;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.SURPLUS_INTEREST
     *
     * @param surplusInterest the value for report_collection_overdue_info.SURPLUS_INTEREST
     *
     * @mbggenerated
     */
    public void setSurplusInterest(BigDecimal surplusInterest) {
        this.surplusInterest = surplusInterest;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OVERDUE_INTEREST
     *
     * @return the value of report_collection_overdue_info.OVERDUE_INTEREST
     *
     * @mbggenerated
     */
    public BigDecimal getOverdueInterest() {
        return overdueInterest;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OVERDUE_INTEREST
     *
     * @param overdueInterest the value for report_collection_overdue_info.OVERDUE_INTEREST
     *
     * @mbggenerated
     */
    public void setOverdueInterest(BigDecimal overdueInterest) {
        this.overdueInterest = overdueInterest;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OVERDUE_PENALTY
     *
     * @return the value of report_collection_overdue_info.OVERDUE_PENALTY
     *
     * @mbggenerated
     */
    public BigDecimal getOverduePenalty() {
        return overduePenalty;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OVERDUE_PENALTY
     *
     * @param overduePenalty the value for report_collection_overdue_info.OVERDUE_PENALTY
     *
     * @mbggenerated
     */
    public void setOverduePenalty(BigDecimal overduePenalty) {
        this.overduePenalty = overduePenalty;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OVERDUE_LATEFEE
     *
     * @return the value of report_collection_overdue_info.OVERDUE_LATEFEE
     *
     * @mbggenerated
     */
    public BigDecimal getOverdueLatefee() {
        return overdueLatefee;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OVERDUE_LATEFEE
     *
     * @param overdueLatefee the value for report_collection_overdue_info.OVERDUE_LATEFEE
     *
     * @mbggenerated
     */
    public void setOverdueLatefee(BigDecimal overdueLatefee) {
        this.overdueLatefee = overdueLatefee;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.REPAYMENT_PERIODS
     *
     * @return the value of report_collection_overdue_info.REPAYMENT_PERIODS
     *
     * @mbggenerated
     */
    public Long getRepaymentPeriods() {
        return repaymentPeriods;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.REPAYMENT_PERIODS
     *
     * @param repaymentPeriods the value for report_collection_overdue_info.REPAYMENT_PERIODS
     *
     * @mbggenerated
     */
    public void setRepaymentPeriods(Long repaymentPeriods) {
        this.repaymentPeriods = repaymentPeriods;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.EACH_REPAYMENTDAY
     *
     * @return the value of report_collection_overdue_info.EACH_REPAYMENTDAY
     *
     * @mbggenerated
     */
    public Date getEachRepaymentday() {
        return eachRepaymentday;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.EACH_REPAYMENTDAY
     *
     * @param eachRepaymentday the value for report_collection_overdue_info.EACH_REPAYMENTDAY
     *
     * @mbggenerated
     */
    public void setEachRepaymentday(Date eachRepaymentday) {
        this.eachRepaymentday = eachRepaymentday;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.EACH_REPAYMENTAMOUNT
     *
     * @return the value of report_collection_overdue_info.EACH_REPAYMENTAMOUNT
     *
     * @mbggenerated
     */
    public BigDecimal getEachRepaymentamount() {
        return eachRepaymentamount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.EACH_REPAYMENTAMOUNT
     *
     * @param eachRepaymentamount the value for report_collection_overdue_info.EACH_REPAYMENTAMOUNT
     *
     * @mbggenerated
     */
    public void setEachRepaymentamount(BigDecimal eachRepaymentamount) {
        this.eachRepaymentamount = eachRepaymentamount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OTHER_AMOUNT
     *
     * @return the value of report_collection_overdue_info.OTHER_AMOUNT
     *
     * @mbggenerated
     */
    public BigDecimal getOtherAmount() {
        return otherAmount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OTHER_AMOUNT
     *
     * @param otherAmount the value for report_collection_overdue_info.OTHER_AMOUNT
     *
     * @mbggenerated
     */
    public void setOtherAmount(BigDecimal otherAmount) {
        this.otherAmount = otherAmount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OVERDUE_DATE
     *
     * @return the value of report_collection_overdue_info.OVERDUE_DATE
     *
     * @mbggenerated
     */
    public Date getOverdueDate() {
        return overdueDate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OVERDUE_DATE
     *
     * @param overdueDate the value for report_collection_overdue_info.OVERDUE_DATE
     *
     * @mbggenerated
     */
    public void setOverdueDate(Date overdueDate) {
        this.overdueDate = overdueDate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OVERDUE_PERIODS
     *
     * @return the value of report_collection_overdue_info.OVERDUE_PERIODS
     *
     * @mbggenerated
     */
    public Long getOverduePeriods() {
        return overduePeriods;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OVERDUE_PERIODS
     *
     * @param overduePeriods the value for report_collection_overdue_info.OVERDUE_PERIODS
     *
     * @mbggenerated
     */
    public void setOverduePeriods(Long overduePeriods) {
        this.overduePeriods = overduePeriods;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OVERDUE_DAY
     *
     * @return the value of report_collection_overdue_info.OVERDUE_DAY
     *
     * @mbggenerated
     */
    public Long getOverdueDay() {
        return overdueDay;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OVERDUE_DAY
     *
     * @param overdueDay the value for report_collection_overdue_info.OVERDUE_DAY
     *
     * @mbggenerated
     */
    public void setOverdueDay(Long overdueDay) {
        this.overdueDay = overdueDay;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.REPAYMENT_AMOUNT
     *
     * @return the value of report_collection_overdue_info.REPAYMENT_AMOUNT
     *
     * @mbggenerated
     */
    public BigDecimal getRepaymentAmount() {
        return repaymentAmount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.REPAYMENT_AMOUNT
     *
     * @param repaymentAmount the value for report_collection_overdue_info.REPAYMENT_AMOUNT
     *
     * @mbggenerated
     */
    public void setRepaymentAmount(BigDecimal repaymentAmount) {
        this.repaymentAmount = repaymentAmount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.ALREADY_REPAYPERIODS
     *
     * @return the value of report_collection_overdue_info.ALREADY_REPAYPERIODS
     *
     * @mbggenerated
     */
    public Long getAlreadyRepayperiods() {
        return alreadyRepayperiods;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.ALREADY_REPAYPERIODS
     *
     * @param alreadyRepayperiods the value for report_collection_overdue_info.ALREADY_REPAYPERIODS
     *
     * @mbggenerated
     */
    public void setAlreadyRepayperiods(Long alreadyRepayperiods) {
        this.alreadyRepayperiods = alreadyRepayperiods;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.LATELY_REPAYMENTDAY
     *
     * @return the value of report_collection_overdue_info.LATELY_REPAYMENTDAY
     *
     * @mbggenerated
     */
    public Date getLatelyRepaymentday() {
        return latelyRepaymentday;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.LATELY_REPAYMENTDAY
     *
     * @param latelyRepaymentday the value for report_collection_overdue_info.LATELY_REPAYMENTDAY
     *
     * @mbggenerated
     */
    public void setLatelyRepaymentday(Date latelyRepaymentday) {
        this.latelyRepaymentday = latelyRepaymentday;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.LATELY_REPAYMENTAMOUNT
     *
     * @return the value of report_collection_overdue_info.LATELY_REPAYMENTAMOUNT
     *
     * @mbggenerated
     */
    public BigDecimal getLatelyRepaymentamount() {
        return latelyRepaymentamount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.LATELY_REPAYMENTAMOUNT
     *
     * @param latelyRepaymentamount the value for report_collection_overdue_info.LATELY_REPAYMENTAMOUNT
     *
     * @mbggenerated
     */
    public void setLatelyRepaymentamount(BigDecimal latelyRepaymentamount) {
        this.latelyRepaymentamount = latelyRepaymentamount;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.OVERDUE_MANAGEFEE
     *
     * @return the value of report_collection_overdue_info.OVERDUE_MANAGEFEE
     *
     * @mbggenerated
     */
    public BigDecimal getOverdueManagefee() {
        return overdueManagefee;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.OVERDUE_MANAGEFEE
     *
     * @param overdueManagefee the value for report_collection_overdue_info.OVERDUE_MANAGEFEE
     *
     * @mbggenerated
     */
    public void setOverdueManagefee(BigDecimal overdueManagefee) {
        this.overdueManagefee = overdueManagefee;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.COMMISSION_RATE
     *
     * @return the value of report_collection_overdue_info.COMMISSION_RATE
     *
     * @mbggenerated
     */
    public BigDecimal getCommissionRate() {
        return commissionRate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.COMMISSION_RATE
     *
     * @param commissionRate the value for report_collection_overdue_info.COMMISSION_RATE
     *
     * @mbggenerated
     */
    public void setCommissionRate(BigDecimal commissionRate) {
        this.commissionRate = commissionRate;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.CUSTOMER_REPAYMENT_BANK
     *
     * @return the value of report_collection_overdue_info.CUSTOMER_REPAYMENT_BANK
     *
     * @mbggenerated
     */
    public String getCustomerRepaymentBank() {
        return customerRepaymentBank;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.CUSTOMER_REPAYMENT_BANK
     *
     * @param customerRepaymentBank the value for report_collection_overdue_info.CUSTOMER_REPAYMENT_BANK
     *
     * @mbggenerated
     */
    public void setCustomerRepaymentBank(String customerRepaymentBank) {
        this.customerRepaymentBank = customerRepaymentBank == null ? null : customerRepaymentBank.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.CUSTOMER_REPAYMENT_CARDNO
     *
     * @return the value of report_collection_overdue_info.CUSTOMER_REPAYMENT_CARDNO
     *
     * @mbggenerated
     */
    public String getCustomerRepaymentCardno() {
        return customerRepaymentCardno;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.CUSTOMER_REPAYMENT_CARDNO
     *
     * @param customerRepaymentCardno the value for report_collection_overdue_info.CUSTOMER_REPAYMENT_CARDNO
     *
     * @mbggenerated
     */
    public void setCustomerRepaymentCardno(String customerRepaymentCardno) {
        this.customerRepaymentCardno = customerRepaymentCardno == null ? null : customerRepaymentCardno.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.·CUSTOMER_NAME·
     *
     * @return the value of report_collection_overdue_info.·CUSTOMER_NAME·
     *
     * @mbggenerated
     */
    public String get·customerName·() {
        return ·customerName·;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.·CUSTOMER_NAME·
     *
     * @param ·customerName· the value for report_collection_overdue_info.·CUSTOMER_NAME·
     *
     * @mbggenerated
     */
    public void set·customerName·(String ·customerName·) {
        this.·customerName· = ·customerName· == null ? null : ·customerName·.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.IDENTITY_NO
     *
     * @return the value of report_collection_overdue_info.IDENTITY_NO
     *
     * @mbggenerated
     */
    public String getIdentityNo() {
        return identityNo;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.IDENTITY_NO
     *
     * @param identityNo the value for report_collection_overdue_info.IDENTITY_NO
     *
     * @mbggenerated
     */
    public void setIdentityNo(String identityNo) {
        this.identityNo = identityNo == null ? null : identityNo.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.MOBILE_NO
     *
     * @return the value of report_collection_overdue_info.MOBILE_NO
     *
     * @mbggenerated
     */
    public String getMobileNo() {
        return mobileNo;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.MOBILE_NO
     *
     * @param mobileNo the value for report_collection_overdue_info.MOBILE_NO
     *
     * @mbggenerated
     */
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo == null ? null : mobileNo.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.MARRIAGE_STATUS
     *
     * @return the value of report_collection_overdue_info.MARRIAGE_STATUS
     *
     * @mbggenerated
     */
    public String getMarriageStatus() {
        return marriageStatus;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.MARRIAGE_STATUS
     *
     * @param marriageStatus the value for report_collection_overdue_info.MARRIAGE_STATUS
     *
     * @mbggenerated
     */
    public void setMarriageStatus(String marriageStatus) {
        this.marriageStatus = marriageStatus == null ? null : marriageStatus.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.PROVINCE
     *
     * @return the value of report_collection_overdue_info.PROVINCE
     *
     * @mbggenerated
     */
    public String getProvince() {
        return province;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.PROVINCE
     *
     * @param province the value for report_collection_overdue_info.PROVINCE
     *
     * @mbggenerated
     */
    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.CITY
     *
     * @return the value of report_collection_overdue_info.CITY
     *
     * @mbggenerated
     */
    public String getCity() {
        return city;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.CITY
     *
     * @param city the value for report_collection_overdue_info.CITY
     *
     * @mbggenerated
     */
    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.HOMEADDRESS
     *
     * @return the value of report_collection_overdue_info.HOMEADDRESS
     *
     * @mbggenerated
     */
    public String getHomeaddress() {
        return homeaddress;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.HOMEADDRESS
     *
     * @param homeaddress the value for report_collection_overdue_info.HOMEADDRESS
     *
     * @mbggenerated
     */
    public void setHomeaddress(String homeaddress) {
        this.homeaddress = homeaddress == null ? null : homeaddress.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.HOMEPHONE
     *
     * @return the value of report_collection_overdue_info.HOMEPHONE
     *
     * @mbggenerated
     */
    public String getHomephone() {
        return homephone;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.HOMEPHONE
     *
     * @param homephone the value for report_collection_overdue_info.HOMEPHONE
     *
     * @mbggenerated
     */
    public void setHomephone(String homephone) {
        this.homephone = homephone == null ? null : homephone.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.IDENTITY_REGISTER_ADDRESS
     *
     * @return the value of report_collection_overdue_info.IDENTITY_REGISTER_ADDRESS
     *
     * @mbggenerated
     */
    public String getIdentityRegisterAddress() {
        return identityRegisterAddress;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.IDENTITY_REGISTER_ADDRESS
     *
     * @param identityRegisterAddress the value for report_collection_overdue_info.IDENTITY_REGISTER_ADDRESS
     *
     * @mbggenerated
     */
    public void setIdentityRegisterAddress(String identityRegisterAddress) {
        this.identityRegisterAddress = identityRegisterAddress == null ? null : identityRegisterAddress.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.WORK_COMPANY_NAME
     *
     * @return the value of report_collection_overdue_info.WORK_COMPANY_NAME
     *
     * @mbggenerated
     */
    public String getWorkCompanyName() {
        return workCompanyName;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.WORK_COMPANY_NAME
     *
     * @param workCompanyName the value for report_collection_overdue_info.WORK_COMPANY_NAME
     *
     * @mbggenerated
     */
    public void setWorkCompanyName(String workCompanyName) {
        this.workCompanyName = workCompanyName == null ? null : workCompanyName.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.WORK_COMPANY_ADDRESS
     *
     * @return the value of report_collection_overdue_info.WORK_COMPANY_ADDRESS
     *
     * @mbggenerated
     */
    public String getWorkCompanyAddress() {
        return workCompanyAddress;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.WORK_COMPANY_ADDRESS
     *
     * @param workCompanyAddress the value for report_collection_overdue_info.WORK_COMPANY_ADDRESS
     *
     * @mbggenerated
     */
    public void setWorkCompanyAddress(String workCompanyAddress) {
        this.workCompanyAddress = workCompanyAddress == null ? null : workCompanyAddress.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.WORK_COMPANY_PHONE
     *
     * @return the value of report_collection_overdue_info.WORK_COMPANY_PHONE
     *
     * @mbggenerated
     */
    public String getWorkCompanyPhone() {
        return workCompanyPhone;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.WORK_COMPANY_PHONE
     *
     * @param workCompanyPhone the value for report_collection_overdue_info.WORK_COMPANY_PHONE
     *
     * @mbggenerated
     */
    public void setWorkCompanyPhone(String workCompanyPhone) {
        this.workCompanyPhone = workCompanyPhone == null ? null : workCompanyPhone.trim();
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method returns the value of the database column report_collection_overdue_info.REMARKS
     *
     * @return the value of report_collection_overdue_info.REMARKS
     *
     * @mbggenerated
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * This method was generated by MyBatis Generator.
     * This method sets the value of the database column report_collection_overdue_info.REMARKS
     *
     * @param remarks the value for report_collection_overdue_info.REMARKS
     *
     * @mbggenerated
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }
}